#include "header.h"

void    file_read()
{
    int num;
    FILE *fptr;


     if ((fptr = fopen("~Downloads:\\c_memorable_moments (1).txt","r")) == NULL)
     {
       printf("Error! opening file");
       exit(1);
     }
     fscanf(fptr,"%d", &num);
     printf("Value of n=%d", num);
     fclose(fptr); 
  
       
}